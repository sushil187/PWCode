<?php
include('dbConnection.php');

 

$sql = "select * from pwconnects";
$result = oci_parse($connection, $sql);
oci_execute($result);
/* $count = oci_num_rows($result);
echo $count; */
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/hotel_logo.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="assets/css/feathericon.min.css">

	<link rel="stylesheet" href="assets/plugins/morris/morris.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
		<!-- Header -->
		<div class="header">

			<!-- Logo -->
			<div class="header-left">
				<a href="index.html" class="logo">
                    <img src="assets/img/hotel_logo.png" width="50" height="70" alt="logo">
                    <span class="logoclass">Vodafone</span>
				</a>
				<a href="index.html" class="logo logo-small">
					<img src="assets/img/hotel_logo.png" alt="Logo" width="30" height="30">
				</a>
			</div>
			<!-- /Logo -->
			<a href="javascript:void(0);" id="toggle_btn">
				<i class="fe fe-text-align-left"></i>
			</a>




			<!-- Mobile Menu Toggle -->
			<a class="mobile_btn" id="mobile_btn">
				<i class="fa fa-bars"></i>
			</a>
			<!-- /Mobile Menu Toggle -->

			<!-- Header Right Menu -->
			<ul class="nav user-menu">
				
				<!-- Notifications -->
				<li class="nav-item dropdown noti-dropdown">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
						<i class="fe fe-bell"></i> <span class="badge badge-pill">3</span>
					</a>
					<div class="dropdown-menu notifications">
						<div class="topnav-dropdown-header">
							<span class="notification-title">Notifications</span>
							<a href="javascript:void(0)" class="clear-noti"> Clear All </a>
						</div>
						<div class="noti-content">
							<ul class="notification-list">
								<li class="notification-message">
									<a href="#">
										<div class="media">
											<span class="avatar avatar-sm">
												<img class="avatar-img rounded-circle" alt="User Image"
													src="assets/img/profiles/avatar-02.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Carlson Tech</span> has
													approved <span class="noti-title">your estimate</span></p>
												<p class="noti-time"><span class="notification-time">4 mins ago</span>
												</p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="#">
										<div class="media">
											<span class="avatar avatar-sm">
												<img class="avatar-img rounded-circle" alt="User Image"
													src="assets/img/profiles/avatar-11.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">International Software
														Inc</span> has sent you a invoice in the amount of <span
														class="noti-title">$218</span></p>
												<p class="noti-time"><span class="notification-time">6 mins ago</span>
												</p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="#">
										<div class="media">
											<span class="avatar avatar-sm">
												<img class="avatar-img rounded-circle" alt="User Image"
													src="assets/img/profiles/avatar-17.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">John Hendry</span> sent
													a cancellation request <span class="noti-title">Apple iPhone
														XR</span></p>
												<p class="noti-time"><span class="notification-time">8 mins ago</span>
												</p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="#">
										<div class="media">
											<span class="avatar avatar-sm">
												<img class="avatar-img rounded-circle" alt="User Image"
													src="assets/img/profiles/avatar-13.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Mercury Software
														Inc</span> added a new product <span class="noti-title">Apple
														MacBook Pro</span></p>
												<p class="noti-time"><span class="notification-time">12 mins ago</span>
												</p>
											</div>
										</div>
									</a>
								</li>
							</ul>
						</div>
						<div class="topnav-dropdown-footer">
							<a href="#">View all Notifications</a>
						</div>
					</div>
				</li>
				<!-- /Notifications -->

				<!-- User Menu -->
				<li class="nav-item dropdown has-arrow">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
						<span class="user-img"><img class="rounded-circle" src="assets/img/profiles/shoaib.jpg"
								width="31" alt="Admin"></span>
					</a>
					<div class="dropdown-menu">
						<div class="user-header">
							<div class="avatar avatar-sm">
								<img src="assets/img/profiles/shoaib.jpg" alt="User Image"
									class="avatar-img rounded-circle">
							</div>
							<div class="user-text">
								<h6>Admin</h6>
								<p class="text-muted mb-0">Administrator</p>
							</div>
						</div>
						<a class="dropdown-item" href="#profile.html">My Profile</a>
						<a class="dropdown-item" href="#settings.html">Account Settings</a>
						<a class="dropdown-item" href="#login.html">Logout</a>
					</div>
				</li>
				<!-- /User Menu -->

			</ul>
			<!-- /Header Right Menu -->

		</div>
		<!-- /Header -->
			<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li>
								<a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
							</li>
							<li class="list-divider"></li>
	
	
							<li class="">
								<a href="all-users.php"><i class="fa fa-suitcase"></i> <span> PW Users </span> <span
										class="menu-arrow"></span></a>
							</li>
							<li class="active">
								<a href="#"><i class="fa fa-user"></i> <span> PW Connects </span> <span
										class="menu-arrow"></span></a>
							</li>
						   
							
							<li class="">
								<a href="all-roles.php"><i class="fa fa-key"></i> <span> PW Roles </span> <span
										class="menu-arrow"></span></a>
							</li>
							<li class="">
								<a href="all-groups.php"><i class="fa fa-user"></i> <span> PW Groups </span> <span
										class="menu-arrow"></span></a>
							</li>
							
						</ul>
					</div>
				</div>
			</div>
			<!-- /Sidebar -->
		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content container-fluid">
				<div class="page-header">
				    <div class="row align-items-center">
						<div class="col">
							<div class="mt-5">
								<h4 class="card-title float-left mt-2">PW Connects</h4>
								<a href="#add-booking.html" class="btn btn-primary float-right veiwbutton ">Add
									Connection</a>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-12">
							<form>
								<div class="row formtype">
									<div class="col-md-3">
										<div class="form-group">
											<label>System</label>
											<input class="form-control" type="text" value="BKG-0001">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>User</label>
											<input class="form-control" type="text" value="BKG-0001">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Category</label>
											<select class="form-control" id="sel1" name="sellist1">
												<option>Select</option>
												<option>Unix</option>
												<option>Application</option>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Search</label>
											<a href="#" class="btn btn-success btn-block mt-0 search_button"> Search </a>
											<!-- <div class="form-group">
												<label>Food</label>
											 
											</div>
											<button type="button" class="btn btn-secondary">Secondary</button> -->
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-12">

						<div class="card card-table">
							<!-- <div class="card-header">
									<h4 class="card-title">List of Users</h4>
								</div> -->
							<div class="card-body booking_card">
								<div class="table-responsive">
									<table class="datatable table table-stripped table table-hover table-center mb-0">
										<thead>
											<tr>
												<th>System</th>
												<th>Connect User</th>
												<th>Connect Password</th>
												<th>Category</th>
												<th>Date Granted</th>
												<th>Status</th>
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tbody>
                                          <?php
                                            if(1) {
                                               while($row = oci_fetch_assoc($result)){
                                                    echo '
														<tr>
															<td>'.$row["SYSTEM"].'</td>
															<td>'.$row["CONNECT_USER"].'</td>
															<td>'.$row["CONNECT_PASSWORD"].'</td>
															<td>'.$row["CATEGORY"].'</td>
															<td>'.$row["GRANTED_DATE"].'</td>
															<td>'.$row["STATUS"].'</td>
															<td class="text-right">
															<div class="dropdown dropdown-action">
															<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v ellipse_color"></i></a>
															<div class="dropdown-menu dropdown-menu-right">
															<a class="dropdown-item" href="#edit-booking.html"><i class="fa fa-pencil m-r-5"></i> Edit</a>
															<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
															</div>
															</div>
															</td>
														</tr>
                                                    ';
                                                }
                                            }

                                            else{
                                              echo "No record found";
                                            }
                                        ?>
                                      </tbody>
									</table>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
			<div id="delete_asset" class="modal fade delete-modal" role="dialog">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-body text-center">
							<img src="assets/img/sent.png" alt="" width="50" height="46">
							<h3 class="delete_class">Are you sure want to delete this Asset?</h3>
							<div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
								<button type="submit" class="btn btn-danger">Delete</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Page Wrapper -->
	</div>
	<!-- /Main Wrapper -->
	<!-- jQuery -->
	<script src="assets/js/jquery-3.2.1.min.js"></script>
	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Slimscroll JS -->
	<!-- Datatables JS -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/plugins/raphael/raphael.min.js"></script>
	<script src="assets/js/script.js"></script>
</body>


<!-- Mirrored from dreamguys.co.in/preadmin/hotel2/all-booking.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 19 Jan 2021 11:08:02 GMT -->
</html>
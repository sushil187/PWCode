<?php

 

$username = "SYSTEM";
$password = "S456l@qw";
$dbname = "139.47.169.67/PWEngine";

 

$connection = oci_connect($username, $password, $dbname);

 

if(!$connection){
    echo "somthing wrong";
}
 

?>